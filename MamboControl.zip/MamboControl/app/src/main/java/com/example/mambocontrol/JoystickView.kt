package com.example.mambocontrol

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** On-screen analog stick. Outputs x and y in -1..1 (up = +y). Springs back to center. */
class JoystickView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var onMove: ((x: Float, y: Float) -> Unit)? = null
    var label: String = ""
        set(value) { field = value; invalidate() }

    var xValue = 0f
        private set
    var yValue = 0f
        private set

    private val deadZone = 0.08f
    private var knobX = 0f
    private var knobY = 0f

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(40, 255, 255, 255) }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 255, 255, 255); strokeWidth = 2f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x4F, 0xC3, 0xF7) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 255, 255, 255); textAlign = Paint.Align.CENTER
        textSize = 14f * resources.displayMetrics.scaledDensity
    }

    private fun radius() = min(width, height) / 2f * 0.85f

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = radius()
        c.drawCircle(cx, cy, r, basePaint)
        c.drawCircle(cx, cy, r, ringPaint)
        c.drawLine(cx - r, cy, cx + r, cy, linePaint)
        c.drawLine(cx, cy - r, cx, cy + r, linePaint)
        c.drawCircle(cx + knobX * r, cy - knobY * r, r * 0.3f, knobPaint)
        if (label.isNotEmpty()) c.drawText(label, cx, cy + r + textPaint.textSize * 1.2f, textPaint)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val r = radius()
                var dx = (e.x - width / 2f) / r
                var dy = (height / 2f - e.y) / r
                val len = sqrt(dx * dx + dy * dy)
                if (len > 1f) { dx /= len; dy /= len }
                update(dx, dy)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> update(0f, 0f)
        }
        return true
    }

    private fun update(x: Float, y: Float) {
        knobX = x
        knobY = y
        xValue = if (abs(x) < deadZone) 0f else x
        yValue = if (abs(y) < deadZone) 0f else y
        onMove?.invoke(xValue, yValue)
        invalidate()
    }
}
