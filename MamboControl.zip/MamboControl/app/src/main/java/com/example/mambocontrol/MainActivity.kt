package com.example.mambocontrol

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity(), MamboController.Listener {

    private lateinit var mambo: MamboController
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var stateText: TextView
    private lateinit var speedText: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var connectBtn: Button
    private lateinit var leftStick: JoystickView
    private lateinit var rightStick: JoystickView

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) mambo.connect()
            else onStatus("Bluetooth permission is needed to find the drone")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mambo = MamboController(this, this)

        statusText = findViewById(R.id.statusText)
        batteryText = findViewById(R.id.batteryText)
        stateText = findViewById(R.id.stateText)
        speedText = findViewById(R.id.speedText)
        speedBar = findViewById(R.id.speedBar)
        connectBtn = findViewById(R.id.connectBtn)
        leftStick = findViewById(R.id.leftStick)
        rightStick = findViewById(R.id.rightStick)

        leftStick.label = "Up/Down · Turn"
        rightStick.label = "Forward/Back · Strafe"

        connectBtn.setOnClickListener {
            if (mambo.isConnected) mambo.disconnect() else startConnect()
        }
        findViewById<Button>(R.id.takeoffBtn).setOnClickListener { mambo.takeOff() }
        findViewById<Button>(R.id.landBtn).setOnClickListener { mambo.land() }
        findViewById<Button>(R.id.trimBtn).setOnClickListener { mambo.flatTrim() }
        findViewById<Button>(R.id.emergencyBtn).setOnClickListener { mambo.emergency() }

        leftStick.onMove = { _, _ -> pushSticks() }
        rightStick.onMove = { _, _ -> pushSticks() }

        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                speedText.text = getString(R.string.speed_fmt, speedPercent())
                pushSticks()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        speedText.text = getString(R.string.speed_fmt, speedPercent())
    }

    /** SeekBar 0..80 → 20..100 % */
    private fun speedPercent() = 20 + speedBar.progress

    private fun pushSticks() {
        val s = speedPercent()
        mambo.setPilot(
            roll = (rightStick.xValue * s).toInt(),
            pitch = (rightStick.yValue * s).toInt(),
            yaw = (leftStick.xValue * s).toInt(),
            vertical = (leftStick.yValue * s).toInt()
        )
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun startConnect() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) mambo.connect() else permLauncher.launch(missing.toTypedArray())
    }

    override fun onDestroy() {
        if (mambo.isConnected) mambo.disconnect()
        super.onDestroy()
    }

    // ---- MamboController.Listener (called on main thread) ----

    override fun onStatus(text: String) { statusText.text = text }

    override fun onConnected() { connectBtn.text = getString(R.string.disconnect) }

    override fun onDisconnected() {
        connectBtn.text = getString(R.string.connect)
        batteryText.text = getString(R.string.battery_unknown)
        stateText.text = ""
    }

    override fun onBattery(percent: Int) { batteryText.text = getString(R.string.battery_fmt, percent) }

    override fun onFlyingState(state: String) { stateText.text = state }
}
