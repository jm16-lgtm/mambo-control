package com.example.mambocontrol

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.UUID

/**
 * Talks to a Parrot Mambo (and other Parrot "minidrones") over Bluetooth Low Energy
 * using Parrot's ARSDK BLE frame format:
 *   [frameType, sequence, project, class, commandId (uint16 LE), args...]
 *
 * All BLE operations are serialized through a queue on the main thread,
 * because Android only allows one GATT operation in flight at a time.
 */
@SuppressLint("MissingPermission")
class MamboController(context: Context, private val listener: Listener) {

    interface Listener {
        fun onStatus(text: String)
        fun onConnected()
        fun onDisconnected()
        fun onBattery(percent: Int)
        fun onFlyingState(state: String)
    }

    private companion object {
        fun uuid(short: String): UUID = UUID.fromString("9a66$short-0800-9191-11e4-012d1540cb8e")

        val SEND_NO_ACK = uuid("fa0a")        // piloting (PCMD)
        val SEND_WITH_ACK = uuid("fa0b")      // normal commands
        val SEND_HIGH_PRIORITY = uuid("fa0c") // emergency
        val ACK_COMMAND = uuid("fa1e")        // our acks of drone packets
        val RECV_WITH_ACK = uuid("fb0e")

        val NOTIFY_UUIDS = listOf(
            "fb0f", "fb0e", "fb1b", "fb1c", "fd22", "fd23", "fd24", "fd52", "fd53", "fd54"
        ).map { uuid(it) }

        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

        val NAME_PREFIXES = listOf("Mambo_", "Swing_", "Mars_", "Travis_", "Maclan_", "Blaze_", "RS_")

        const val TYPE_ACK = 1
        const val TYPE_DATA = 2
        const val TYPE_LOW_LATENCY = 3
        const val TYPE_DATA_WITH_ACK = 4

        const val PROJECT_COMMON = 0
        const val PROJECT_MINIDRONE = 2

        val FLYING_STATES = listOf(
            "Landed", "Taking off", "Hovering", "Flying", "Landing", "Emergency", "Rolling", "Init"
        )
    }

    private sealed class Op {
        class Write(val ch: BluetoothGattCharacteristic, val data: ByteArray) : Op()
        class Notify(val ch: BluetoothGattCharacteristic) : Op()
        object Pcmd : Op()
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var gatt: BluetoothGatt? = null
    private val chars = HashMap<UUID, BluetoothGattCharacteristic>()
    private val counters = HashMap<UUID, Int>()
    private val queue = ArrayDeque<Op>()
    private var busy = false
    private var busySince = 0L
    private var pcmdQueued = false
    private var scanning = false

    var isConnected = false
        private set

    // Current stick values, -100..100
    private var roll = 0
    private var pitch = 0
    private var yaw = 0
    private var vertical = 0

    // ---------------- Public API ----------------

    fun connect() {
        val a = adapter ?: return report("Bluetooth not available on this device")
        if (!a.isEnabled) return report("Please turn on Bluetooth")
        val scanner = a.bluetoothLeScanner ?: return report("BLE scanner unavailable")
        if (scanning || gatt != null) return
        scanning = true
        report("Scanning for Mambo…")
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, scanCallback)
        main.postDelayed(scanTimeout, 15_000)
    }

    fun disconnect() {
        stopScan()
        gatt?.disconnect()
        cleanup()
        report("Disconnected")
        listener.onDisconnected()
    }

    fun takeOff() = sendCommand(PROJECT_MINIDRONE, 0, 1)
    fun land() = sendCommand(PROJECT_MINIDRONE, 0, 3)
    fun flatTrim() = sendCommand(PROJECT_MINIDRONE, 0, 0)

    /** Cuts the motors immediately. Sent on the high-priority channel, ahead of anything queued. */
    fun emergency() {
        val ch = chars[SEND_HIGH_PRIORITY] ?: chars[SEND_WITH_ACK] ?: return
        repeat(2) {
            val pkt = byteArrayOf(
                TYPE_LOW_LATENCY.toByte(), nextCounter(ch.uuid).toByte(),
                PROJECT_MINIDRONE.toByte(), 0, 4, 0
            )
            enqueue(Op.Write(ch, pkt), front = true)
        }
    }

    /** All values in -100..100. Sent continuously (every 50 ms) while connected. */
    fun setPilot(roll: Int, pitch: Int, yaw: Int, vertical: Int) {
        this.roll = roll.coerceIn(-100, 100)
        this.pitch = pitch.coerceIn(-100, 100)
        this.yaw = yaw.coerceIn(-100, 100)
        this.vertical = vertical.coerceIn(-100, 100)
    }

    // ---------------- Scanning ----------------

    private val scanTimeout = Runnable {
        if (scanning) {
            stopScan()
            report("No Mambo found. Is it switched on and nearby?")
        }
    }

    private fun stopScan() {
        if (!scanning) return
        scanning = false
        main.removeCallbacks(scanTimeout)
        try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.scanRecord?.deviceName ?: result.device.name ?: return
            if (!scanning || NAME_PREFIXES.none { name.startsWith(it) }) return
            stopScan()
            report("Connecting to $name…")
            gatt = result.device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        }

        override fun onScanFailed(errorCode: Int) {
            main.post { scanning = false; report("Scan failed (error $errorCode)") }
        }
    }

    // ---------------- GATT ----------------

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
            main.post {
                if (g !== gatt) return@post
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        report("Discovering services…")
                        g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                        main.postDelayed({ gatt?.discoverServices() }, 300)
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        cleanup()
                        report("Disconnected")
                        listener.onDisconnected()
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            main.post { if (g === gatt) setup(g) }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, ch: BluetoothGattCharacteristic, st: Int) {
            main.post { opDone() }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
            main.post { opDone() }
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray
        ) {
            val copy = value.copyOf()
            val id = ch.uuid
            main.post { handleData(id, copy) }
        }

        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return
            val copy = ch.value?.copyOf() ?: return
            val id = ch.uuid
            main.post { handleData(id, copy) }
        }
    }

    private fun setup(g: BluetoothGatt) {
        chars.clear()
        for (s in g.services) for (c in s.characteristics) chars[c.uuid] = c

        if (chars[SEND_WITH_ACK] == null || chars[SEND_NO_ACK] == null) {
            report("That device doesn't look like a Parrot minidrone")
            disconnect()
            return
        }

        NOTIFY_UUIDS.mapNotNull { chars[it] }.forEach { enqueue(Op.Notify(it)) }
        sendCommand(PROJECT_COMMON, 4, 0) // Common.Common.AllStates → battery, flying state, …

        isConnected = true
        report("Connected")
        listener.onConnected()
        main.post(pcmdLoop)
    }

    private fun cleanup() {
        main.removeCallbacks(pcmdLoop)
        gatt?.close()
        gatt = null
        isConnected = false
        queue.clear()
        busy = false
        pcmdQueued = false
        chars.clear()
        counters.clear()
    }

    // ---------------- Operation queue ----------------

    private fun enqueue(op: Op, front: Boolean = false) {
        if (front) queue.addFirst(op) else queue.addLast(op)
        if (!busy) next()
    }

    private fun opDone() {
        busy = false
        next()
    }

    private fun next() {
        val g = gatt ?: return
        val op = queue.removeFirstOrNull() ?: return
        busy = true
        busySince = SystemClock.elapsedRealtime()
        val ok = when (op) {
            is Op.Notify -> enableNotify(g, op.ch)
            is Op.Write -> write(g, op.ch, op.data)
            Op.Pcmd -> {
                pcmdQueued = false
                val ch = chars[SEND_NO_ACK]
                ch != null && write(g, ch, buildPcmd())
            }
        }
        if (!ok) {
            busy = false
            main.post { if (!busy) next() }
        }
    }

    private val pcmdLoop = object : Runnable {
        override fun run() {
            if (!isConnected) return
            // Watchdog: never let a lost callback stall the queue.
            if (busy && SystemClock.elapsedRealtime() - busySince > 1000) opDone()
            if (!pcmdQueued) {
                pcmdQueued = true
                enqueue(Op.Pcmd)
            }
            main.postDelayed(this, 50)
        }
    }

    @Suppress("DEPRECATION")
    private fun write(g: BluetoothGatt, ch: BluetoothGattCharacteristic, data: ByteArray): Boolean {
        val type = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(ch, data, type) == BluetoothStatusCodes.SUCCESS
        } else {
            ch.writeType = type
            ch.value = data
            g.writeCharacteristic(ch)
        }
    }

    @Suppress("DEPRECATION")
    private fun enableNotify(g: BluetoothGatt, ch: BluetoothGattCharacteristic): Boolean {
        g.setCharacteristicNotification(ch, true)
        val d = ch.getDescriptor(CCCD) ?: return false
        val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, v) == BluetoothStatusCodes.SUCCESS
        } else {
            d.value = v
            g.writeDescriptor(d)
        }
    }

    // ---------------- Packets ----------------

    private fun nextCounter(id: UUID): Int {
        val n = ((counters[id] ?: 0) + 1) and 0xFF
        counters[id] = n
        return n
    }

    private fun sendCommand(project: Int, cls: Int, cmd: Int) {
        val ch = chars[SEND_WITH_ACK] ?: return
        val pkt = byteArrayOf(
            TYPE_DATA_WITH_ACK.toByte(), nextCounter(SEND_WITH_ACK).toByte(),
            project.toByte(), cls.toByte(), (cmd and 0xFF).toByte(), (cmd shr 8).toByte()
        )
        enqueue(Op.Write(ch, pkt))
    }

    /** minidrone.Piloting.PCMD: flag, roll, pitch, yaw, gaz (int8 each), timestamp (uint32). */
    private fun buildPcmd(): ByteArray = byteArrayOf(
        TYPE_DATA.toByte(), nextCounter(SEND_NO_ACK).toByte(),
        PROJECT_MINIDRONE.toByte(), 0, 2, 0,
        1, roll.toByte(), pitch.toByte(), yaw.toByte(), vertical.toByte(),
        0, 0, 0, 0
    )

    private fun sendAck(seq: Byte) {
        val ch = chars[ACK_COMMAND] ?: return
        enqueue(Op.Write(ch, byteArrayOf(TYPE_ACK.toByte(), nextCounter(ACK_COMMAND).toByte(), seq)))
    }

    private fun handleData(id: UUID, data: ByteArray) {
        if (data.size < 2) return
        val type = data[0].toInt() and 0xFF
        if (id == RECV_WITH_ACK || type == TYPE_DATA_WITH_ACK) sendAck(data[1])
        if (type == TYPE_ACK || data.size < 7) return

        val project = data[2].toInt() and 0xFF
        val cls = data[3].toInt() and 0xFF
        val cmd = (data[4].toInt() and 0xFF) or ((data[5].toInt() and 0xFF) shl 8)
        val arg = data[6].toInt() and 0xFF

        when {
            project == PROJECT_COMMON && cls == 5 && cmd == 1 ->
                listener.onBattery(arg)
            project == PROJECT_MINIDRONE && cls == 3 && cmd == 1 ->
                listener.onFlyingState(FLYING_STATES.getOrElse(arg) { "Unknown" })
        }
    }

    private fun report(text: String) = listener.onStatus(text)
}
