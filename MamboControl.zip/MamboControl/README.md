# Mambo Control (Android)

A small Android app that flies a Parrot Mambo over Bluetooth LE.

## Build
1. Install Android Studio (any recent version).
2. File → Open → select the `MamboControl` folder. Let Gradle sync.
3. Plug in your phone (USB debugging on) and press Run.

## Fly
1. Put the Mambo on a flat surface and switch it on.
2. Tap **Connect** and allow the Bluetooth permission.
3. Tap **Flat trim** once while it sits level, then **Take off**.
4. Left stick: up/down and turn. Right stick: forward/back and sideways.
5. The speed slider limits how hard the sticks push (start low).
6. **EMERGENCY STOP** cuts the motors instantly (the drone will drop).

## Notes
- Works with Android 7.0+. On Android 11 and older, Location must be switched on for BLE scanning.
- Also looks for other Parrot minidrones (Swing, Rolling Spider, etc.) by name.
- Fly indoors in open space, away from people and faces.
